package ie.gmit.sw.ai.mazeAlgos.traversers;

import ie.gmit.sw.ai.mazeAlgos.maze.*;
public interface Traversator {
	public void traverse(Node[][] maze, Node start);
}
