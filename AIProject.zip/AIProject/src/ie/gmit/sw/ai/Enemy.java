package ie.gmit.sw.ai;

public class Enemy {

	private int strength;
	
	public Enemy()
	{
		
	}
	
	public Enemy(int strength)
	{
		
	}
	
	public int getStrength() {
		return strength;
	}

	public void setStrength(int strength) {
		this.strength = strength;
	}

}
