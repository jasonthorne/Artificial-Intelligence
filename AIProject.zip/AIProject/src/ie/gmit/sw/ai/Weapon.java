package ie.gmit.sw.ai;

public class Weapon {

	private int power;
	
	public Weapon()
	{
		
	}
	public Weapon(int power)
	{
		
	}
	
	public int getPower() {
		return power;
	}
	public void setPower(int power) {
		this.power = power;
	}
}
