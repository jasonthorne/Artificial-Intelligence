package ie.gmit.sw.ai;

public class Player {

	private int life;

	public Player()
	{
		
	}
	
	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}
}
